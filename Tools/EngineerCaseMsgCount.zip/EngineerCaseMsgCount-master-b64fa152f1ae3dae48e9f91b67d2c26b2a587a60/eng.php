<?php
	//ini_set("error_reporting","E_ALL & ~E_NOTICE");
	date_default_timezone_set('Asia/Shanghai');
	set_time_limit(0);

    $ssql="SELECT caseid,uid,engid FROM `ls_case` WHERE `engid` = '65187' AND `create_time` >= '2017-11-29 00:00:00' AND `create_time` <= '2017-11-29 23:59:59'";
	$case_arr=selectData5($ssql);//对列
$i = 0;

	foreach($case_arr as $k =>$v){
		$sql = "SELECT id FROM ls_case_id WHERE uid = '". $v['uid']."'";
        $case_msg_id = caseId($sql);

		if(!empty($case_msg_id)){
            $table_no=$case_msg_id['id']%100;
			$caseMsg[$v['caseid']] = $table_no;
        }else {
			$caseMsg[$v['caseid']] = 0;
        }
	}
	//echo '<pre>';print_R($caseMsg);exit;
    $caseArr = '';
	foreach($case_arr as $k=>$v){

        if($caseMsg[$v['caseid']] == 0){
			$sql = "SELECT count(*) as num FROM  ls_case_msg_0 where caseid = '".$v['caseid']."'";
        }else {
            $sql = "SELECT count(*) as num FROM  ls_case_msg_".$caseMsg[$v['caseid']]." where caseid = '".$v['caseid']."'";
        }

        $null_arr = caseMsg($sql);

        if($null_arr['num'] == 0){
            $caseArr[$v['caseid'].'_'.$caseMsg[$v['caseid']]] =$null_arr;
        }
        $i++;
        echo '<pre>';print_R($caseArr);
	}
	echo count($caseArr);
	echo 'eee';
echo '<pre>';print_R($caseArr);exit;


function caseMsg($sql){
    try{
        $mysql_server_name3="10.96.92.41:3307";//数据库服务器名称
        $mysql_username3="wx_case_info";//连接数据库用户名
        $mysql_password3="ha1or2en3";//连接数据库密码
        $conn=@mysql_connect($mysql_server_name3, $mysql_username3,$mysql_password3);
        mysql_query("SET NAMES UTF8", $conn);
        $arr2=array();
        mysql_select_db('wx_case_info',$conn);
        $result = mysql_query($sql,$conn);
        if(!$conn || !$result){
            throw new Exception(mysql_error());
        }
        while($row=@mysql_fetch_assoc($result)){
            $arr2=@$row;
        }
        mysql_close($conn);
        return $arr2;
    }catch(Exception $e){
        add_log('selectData5',$e->getMessage(),$sql);
    }

}
function caseId($sql){
    try{
        $mysql_server_name3="10.96.92.41:3307";//数据库服务器名称
        $mysql_username3="wx_case_info";//连接数据库用户名
        $mysql_password3="ha1or2en3";//连接数据库密码
        $conn=@mysql_connect($mysql_server_name3, $mysql_username3,$mysql_password3);
        mysql_query("SET NAMES UTF8", $conn);
        $arr2=array();
        mysql_select_db('wx_case_info',$conn);
        $result = mysql_query($sql,$conn);
        if(!$conn || !$result){
            throw new Exception(mysql_error());
        }
        while($row=@mysql_fetch_assoc($result)){
            $arr2=@$row;
        }
        mysql_close($conn);
        return $arr2;
    }catch(Exception $e){
        add_log('selectData5',$e->getMessage(),$sql);
    }

}
    function selectData5($sql){
	  try{
		$mysql_server_name3="10.96.92.41:3307";//数据库服务器名称
		$mysql_username3="wx_case";//连接数据库用户名
		$mysql_password3="ha1or2en3";//连接数据库密码
		$conn=@mysql_connect($mysql_server_name3, $mysql_username3,$mysql_password3);

		mysql_query("SET NAMES UTF8", $conn);
		$arr2=array();
		mysql_select_db('wx_case',$conn);
		$result = mysql_query($sql,$conn);
		if(!$conn || !$result){
			throw new Exception(mysql_error());
		}
		while($row=@mysql_fetch_assoc($result)){
			$arr2[]=@$row;
		}
          mysql_close($conn);
		return $arr2;
	  }catch(Exception $e){
		add_log('selectData5',$e->getMessage(),$sql);
	  }

   }
  
  	   //添加日志
    function add_log($operation,$getdata,$setdata){
            $new_line = "\r\n";
            $str  = "时间:" . date("Y-m-d H:i:s");
            $str .= "调用方法:" . $operation . $new_line;           
            $str .= "接收数据:" . json_encode($getdata) . $new_line;
			$str .= "请求数据:" . json_encode($setdata). $new_line;
            $str .= $new_line;
            $file_path = '/crontab/get'.$operation;
            $file_path = rtrim($file_path, "/");
            $filename = $file_path.'/'.date('Ymd').'/'.date("H").".log";
            add_write_file($filename, $str);
     }
    function add_write_file($filename = '', $str = '', $mode = 'a+') {
        $result = FALSE;
        //是否新建目录
        $dirname = dirname($filename);
        if (!file_exists($dirname)) {
            mkdir($dirname, 0777, TRUE);
        }
        $file = fopen($filename, $mode);
        // 排它性的锁定
        if (flock($file, LOCK_EX)) {
            fwrite($file, $str);
            flock($file, LOCK_UN);
            $result = TRUE;
        }
        fclose($file);
        return $result;
    }
  
  
?>

