#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pymysql.cursors
import xlrd
import datetime
import time
import xlwt
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys
import re

#读取工程师ID
def GetEngID():
    data = xlrd.open_workbook( 'engineer.xlsx' )
    table = data.sheets()[0]
    englist = {}
    for i in range(table.nrows):
        try:
            engid, engname = table.row_values( i )
            englist[int(engid)] = {"name" : engname, 'caselist' : [], "success" : 0, "failed" : 0 }
        except ValueError:
            continue
    del table
    idlist = []
    for k, v in englist.items():
        idlist.append( str(k) )
    idStrList = "'" + "','".join( idlist ) + "'"
    del idlist[:]
    return englist, idStrList

#查询工程师最近几天的case
def GetCaseID(englist, idlist, timeStart, timeStop):
    sql_case = 'SELECT caseid,uid,engid,create_time FROM ls_case WHERE create_time >= "{}" AND create_time <= "{}" AND engid in ({})'.format(timeStart, timeStop, idlist)
    connection = pymysql.connect(host='10.96.92.41', port=3307, user='wx_case', password='ha1or2en3', db='wx_case', charset='utf8mb4', cursorclass=pymysql.cursors.DictCursor)
    result = None
    try:
        with connection.cursor() as cursor:
            cursor.execute(sql_case)
            result = cursor.fetchall()
        for v in result:
            englist[ int( v[ 'engid' ] ) ]['caselist'].append({"caseid" : v['caseid'], "uid" : v['uid'], "create_time" : v['create_time']})
    except:
        result = None
    finally:
        connection.close()
    return result

#查询case对应的用户消息存在哪个表
def GetCaseCount(englist, caselist):
    caseidlist = []
    for case in caselist:
        caseidlist.append( str( case['uid'] ) )
    idStrList = "'" + "','".join( caseidlist ) + "'"
    del caseidlist[ : ]
    sql_id = 'SELECT id,uid FROM ls_case_id WHERE uid in ({})'.format(idStrList)
    connection = pymysql.connect( host = '10.96.92.41', port = 3307, user = 'wx_case_info', password = 'ha1or2en3', db = 'wx_case_info', charset = 'utf8mb4', cursorclass = pymysql.cursors.DictCursor )
    result = None
    try :
        with connection.cursor() as cursor :
            cursor.execute( sql_id )
            ls_case_id = cursor.fetchall()
            result = {}
            for v in ls_case_id:
                result[v['uid']] = int(v['id']) % 100
    except:
        result = None
    finally :
        connection.close()
    return result

#查询case对应的消息数量
def GetCaseMsgCount(englist, uidlist):
    def GetCaseMsgThread(engineer):
        connection = pymysql.connect( host = '10.96.92.41', port = 3307, user = 'wx_case_info', password = 'ha1or2en3', db = 'wx_case_info', charset = 'utf8mb4', cursorclass = pymysql.cursors.DictCursor )
        with connection.cursor() as cursor :
            for case in engineer[ 'caselist' ] :
                sql_case = "SELECT count(*) as num, caseid FROM ls_case_msg_{} where caseid = '{}'".format( uidlist.get( case[ 'uid' ], 0 ), case[ 'caseid' ] )
                try :
                    cursor.execute( sql_case )
                    num = cursor.fetchone()
                    case['num'] = num['num']
                except :
                    pass
        connection.close()
    with ThreadPoolExecutor( max_workers = len( englist ) ) as ThreadPool :
        fu_list = []
        for k, v in englist.items() :
            fu_list.append( ThreadPool.submit( GetCaseMsgThread, v ) )
        for fu in as_completed( fu_list ) :
            pass

if __name__ == '__main__':
    timeStart = datetime.datetime.now() + datetime.timedelta( days = -1 )
    timeStop = timeStart
    if len( sys.argv ) > 1:
        if re.match( "^(\d{2}|\d{4})-((0([1-9]{1}))|(1[0|1|2]))-(([0-2]([0-9]{1}))|(3[0|1]))$", sys.argv[1] ) != None :
            timeStart = datetime.datetime.strptime(sys.argv[1], "%Y-%m-%d")
            timeStop = timeStart
    englist, idStrList = GetEngID()
    t1 = time.time()
    caselist = GetCaseID( englist, idStrList, timeStart.strftime( "%Y-%m-%d 00:00:00" ), timeStop.strftime( "%Y-%m-%d 23:59:59" ) )
    uidlist = GetCaseCount( englist, caselist )
    GetCaseMsgCount( englist, uidlist )
    t2 = time.time()
    success, failed, total = 0, 0, 0
    for k, v in englist.items() :
        for case in v[ 'caselist' ] :
            if case['num'] != 0:
                v[ 'success' ] += 1
                success += 1
            else:
                v[ 'failed' ] += 1
                failed += 1
        total += len( v[ 'caselist' ] )
    file = xlwt.Workbook()
    table = file.add_sheet( 'CASE信息', cell_overwrite_ok = True )
    font = xlwt.Font()
    font.name = '微软雅黑'
    font.bold = True
    style = xlwt.XFStyle()
    style.font = font

    table.write( 0, 0, label = '工程师', style = style )
    table.write( 0, 1, label = '正常CASE', style = style )
    table.write( 0, 2, label = '异常CASE', style = style )

    table.col( 0 ).width = 9999
    table.col( 1 ).width = 9999
    table.col( 2 ).width = 9999

    i = 1
    for k, v in englist.items() :
        table.write( i, 0, v['name'] )
        table.write( i, 1, v[ 'success' ] )
        if v['failed'] > 0:
            table.write( i, 2, label = v[ 'failed' ], style = style )
        else:
            table.write( i, 2, v[ 'failed' ] )
        i += 1
    i += 1
    table.write( i, 0, '工程师总数：{}'.format(len(englist)) )
    table.write( i, 1, '正常CASE：{}'.format(success) )
    table.write( i, 2, '异常CASE：{}'.format(failed) )
    i += 1
    table.write( i, 0, '总共耗时：{:.2f}秒'.format( t2 - t1) )
    table.write( i, 1, '平均耗时：{:.2f}秒/工程师'.format( (t2 - t1)/len(englist) ) )
    table.write( i, 2, '异常比例：{:.6f}%'.format( failed * 100 / total ) )
    file.save( timeStart.strftime( "%Y-%m-%d" ) + '.xls' )